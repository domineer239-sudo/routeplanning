import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import pickle # Used to save/load the model

# --- 1. SIMULATE DATA (In a real project, this would be historical telemetry data) ---

# Features: [Distance_km, Hour_of_Day (0-23), Day_of_Week (0=Mon, 6=Sun)]
N_SAMPLES = 1000

# Feature 1: Route Distance (in km)
distances = np.random.uniform(2.0, 50.0, N_SAMPLES)
# Feature 2: Hour of Day (0-23) - Traffic is usually worse during rush hour (7-9, 17-19)
hours = np.random.randint(0, 24, N_SAMPLES)
# Feature 3: Day of Week (0=Monday, 6=Sunday) - Weekend traffic patterns differ
days = np.random.randint(0, 7, N_SAMPLES)

X = np.column_stack([distances, hours, days]) # Our feature matrix

# Target (y): Travel Time / ETA (in seconds)
# Base time: 2 minutes per km (fast average)
base_time = distances * 120 
# Add congestion penalty based on hour (simple rush hour logic)
congestion_penalty = np.where(((hours >= 7) & (hours <= 9)) | ((hours >= 17) & (hours <= 19)), 
                              base_time * 0.4, # 40% slower during rush hour
                              base_time * 0.1)  # 10% slower otherwise
# Add randomness (noise)
noise = np.random.normal(0, 100, N_SAMPLES) # Add noise up to +/- 100 seconds

y = base_time + congestion_penalty + noise
y = np.clip(y, 10, None) # Ensure ETA is at least 10 seconds

# --- 2. TRAIN THE MODEL ---

# Split data (optional for small example, but good practice)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Instantiate the model (Random Forest is robust and handles non-linear relationships well)
print("Training Random Forest Regressor...")
model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
model.fit(X_train, y_train)

# Evaluate the model (Check the Mean Absolute Error)
y_pred = model.predict(X_test)
print(f"Mean Absolute Error (MAE) on test set: {mean_absolute_error(y_test, y_pred):.2f} seconds")

# --- 3. SAVE THE TRAINED MODEL ---
MODEL_FILENAME = 'eta_predictor_model.pkl'

with open(MODEL_FILENAME, 'wb') as file:
    pickle.dump(model, file)
    
print(f"✅ Model successfully trained and saved as {MODEL_FILENAME}")