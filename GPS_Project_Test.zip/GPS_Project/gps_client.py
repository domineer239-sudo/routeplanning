# telemetry_simulator.py (or whatever you named it)

import time
import random
import socketio

sio = socketio.Client()
SERVER = "http://localhost:5000"

# --- Define the Start and End Points for Routing ---
# These coordinates should be the beginning and end of your simulated path
START_POINT = (5.4195, 100.3325) 
DESTINATION = (5.4205, 100.3340) 

@sio.event
def connect():
    print("connected to server")
    # **MODIFICATION:** Request the route immediately after connecting
    print(f"Requesting route from {START_POINT} to {DESTINATION}...")
    sio.emit('request_route', {
        'start': START_POINT,
        'end': DESTINATION
    })

@sio.event
def disconnect():
    print("disconnected")
    
# Optional: Add listener to see the server's route response
@sio.event
def route(data):
    print(f"Route received from server. ETA: {data.get('eta', 'N/A')}s.")


def send_point(lat, lon, speed=5.0, heading=0.0):
    payload = {"lat": lat, "lon": lon, "speed": speed, "heading": heading, "timestamp": time.time()}
    sio.emit('telemetry', payload)

if __name__ == '__main__':
    sio.connect(SERVER)
    
    # **MODIFICATION:** Wait 2 seconds for the server to calculate and store the route
    time.sleep(2) 

    # simple path; uses the same coordinates as the destination fallback in server.py
    path = [
        START_POINT, (5.4197, 100.3328), (5.4199, 100.3331),
        (5.4201, 100.3334), (5.4203, 100.3337), DESTINATION
    ]
    
    print("Starting telemetry simulation...")
    for lat, lon in path:
        send_point(lat, lon, speed=random.uniform(5, 15))
        time.sleep(1.2)
        
    sio.disconnect()