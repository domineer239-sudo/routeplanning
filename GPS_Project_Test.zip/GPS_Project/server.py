import eventlet
# This line MUST be called before any other code that imports blocking modules.
eventlet.monkey_patch()
import os
import time
import math
import requests
import polyline
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit

# -------- CONFIG --------
GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY") # optional: if set, Google Directions will be used
# If GOOGLE_API_KEY is not set, OSRM public demo server will be used for routing.
DESTINATION_DEFAULT = (5.4205, 100.3340) # fallback destination (lat, lon)
ROUTE_CACHE_TTL = 20 # seconds to keep cached route (reduce external calls)
DEVIATION_THRESHOLD_M = 30.0 # meters before we consider re-routing
ETA_CHANGE_THRESHOLD_S = 20 # seconds

# -------- APP SETUP --------
app = Flask(__name__, template_folder="templates")
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="eventlet")

# Simple in-memory session store and route cache
sessions = {} # key: sid -> { 'route': [ (lat,lon) ... ], 'route_time': timestamp, 'eta': seconds }
route_cache = {} # key (origin,dest,provider) -> { 'coords': [...], 'eta': seconds, 'ts': timestamp }

# -------- Utilities --------
def haversine_dist_m(lat1, lon1, lat2, lon2):
    R = 6371000
    phi1 = math.radians(lat1); phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1); dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

def point_to_polyline_distance_m(point, polyline_coords):
    lat0, lon0 = point
    min_d = float('inf')
    if not polyline_coords:
        return min_d
    for i in range(len(polyline_coords)-1):
        lat1, lon1 = polyline_coords[i]
        lat2, lon2 = polyline_coords[i+1]
        for t in [j/10 for j in range(11)]:
            latp = lat1*(1-t) + lat2*t
            lonp = lon1*(1-t) + lon2*t
            d = haversine_dist_m(lat0, lon0, latp, lonp)
            if d < min_d: min_d = d
    return min_d

# -------- Geocoding (Nominatim) --------
@app.route('/geocode')
def geocode():
    q = request.args.get('q')
    if not q:
        return jsonify([])

    url = "https://nominatim.openstreetmap.org/search"
    params = {"q": q, "format": "jsonv2", "limit": 5}
    try:
        r = requests.get(url, params=params, headers={"User-Agent": "RealtimeNavDemo/1.0"}, timeout=10)
        results = r.json()
        out = []
        for item in results:
            out.append({
                "display_name": item.get("display_name"),
                "lat": float(item.get("lat")),
                "lon": float(item.get("lon"))
            })
        return jsonify(out)
    except Exception as e:
        return jsonify([]), 500

# -------- Routing: Google Directions (if key) or OSRM --------
def get_google_route(origin, destination):
    url = "https://maps.googleapis.com/maps/api/directions/json"
    params = {
        "origin": f"{origin[0]},{origin[1]}",
        "destination": f"{destination[0]},{destination[1]}",
        "key": GOOGLE_API_KEY,
        "departure_time": "now",
        "mode": "driving"
    }
    r = requests.get(url, params=params, timeout=10)
    j = r.json()
    if j.get("status") != "OK":
        return None, None
    route = j['routes'][0]
    poly = route['overview_polyline']['points']
    coords = polyline.decode(poly)  # list of (lat,lon)
    eta = 0
    for leg in route.get('legs', []):
        d = leg.get('duration_in_traffic') or leg.get('duration')
        if d and isinstance(d, dict):
            eta += d.get('value', 0)
    return coords, eta

def get_osrm_route(origin, destination):
    base = "https://router.project-osrm.org/route/v1/driving/"
    coords_str = f"{origin[1]},{origin[0]};{destination[1]},{destination[0]}"
    url = base + coords_str
    params = {"overview": "full", "geometries": "geojson", "steps": "false"}
    r = requests.get(url, params=params, timeout=10)
    j = r.json()
    if j.get("code") != "Ok":
        return None, None
    geom = j['routes'][0]['geometry']
    coords = [(lat, lon) for lon, lat in geom['coordinates']]
    eta = int(j['routes'][0].get('duration', 0))
    return coords, eta

def get_route(origin, destination):
    provider = "google" if GOOGLE_API_KEY else "osrm"
    key = (round(origin[0],6), round(origin[1],6), round(destination[0],6), round(destination[1],6), provider)
    now = time.time()
    cached = route_cache.get(key)
    if cached and (now - cached['ts'] < ROUTE_CACHE_TTL):
        return cached['coords'], cached['eta'], provider
    try:
        if GOOGLE_API_KEY:
            coords, eta = get_google_route(origin, destination)
        else:
            coords, eta = get_osrm_route(origin, destination)
    except Exception as e:
        print("Routing error:", e)
        return None, None, provider
    if coords is None:
        return None, None, provider
    route_cache[key] = {'coords': coords, 'eta': eta, 'ts': now}
    return coords, eta, provider

# -------- Flask routes --------
@app.route('/')
def index():
    return render_template('index.html')

# -------- SocketIO Handlers --------
@socketio.on('connect')
def on_connect():
    sid = request.sid
    print("Client connected:", sid)
    sessions[sid] = {'route': None, 'eta': None, 'route_ts': 0}
    emit('connected', {'msg': 'welcome'})

@socketio.on('disconnect')
def on_disconnect():
    sid = request.sid
    print("Client disconnected:", sid)
    if sid in sessions:
        del sessions[sid]

@socketio.on('request_route')
def on_request_route(msg):
    sid = request.sid
    start = msg.get('start')
    end = msg.get('end')
    if not start or not end:
        emit('route_response', {'error': 'invalid start/end'})
        return
    coords, eta, provider = get_route((start[0], start[1]), (end[0], end[1]))
    if coords:
        sessions[sid]['route'] = coords
        sessions[sid]['eta'] = eta
        sessions[sid]['route_ts'] = time.time()
        emit('route', {'route': coords, 'eta': eta, 'provider': provider})
    else:
        emit('route_response', {'error': 'routing_failed'})

@socketio.on('telemetry')
def handle_telemetry(data):
    sid = request.sid
    if sid is None:
        return
    socketio.emit('vehicle_update', {'sid': sid, 'lat': data['lat'], 'lon': data['lon'], 'speed': data.get('speed',0)})
    sess = sessions.get(sid, {})
    current_route = sess.get('route')
    current_eta = sess.get('eta')
    need_reroute = False
    if not current_route:
        need_reroute = True
    else:
        dev_m = point_to_polyline_distance_m((data['lat'], data['lon']), current_route)
        if dev_m > DEVIATION_THRESHOLD_M:
            print(f"Deviated by {dev_m:.1f} m -> rerouting")
            need_reroute = True
        else:
            coords, eta, provider = get_route((data['lat'], data['lon']), current_route[-1])
            if coords and eta is not None:
                if current_eta is None or abs(eta - current_eta) > ETA_CHANGE_THRESHOLD_S:
                    print(f"ETA changed {current_eta} -> {eta} (s). Rerouting.")
                    need_reroute = True
    if need_reroute:
        dest = current_route[-1] if current_route else DESTINATION_DEFAULT
        coords, eta, provider = get_route((data['lat'], data['lon']), dest)
        if coords:
            sessions[sid]['route'] = coords
            sessions[sid]['eta'] = eta
            sessions[sid]['route_ts'] = time.time()
            socketio.emit('route', {'route': coords, 'eta': eta, 'provider': provider})

if __name__ == '__main__':
    print("Starting Realtime Nav Server on http://0.0.0.0:5000")
    socketio.run(app, host='0.0.0.0', port=5000)